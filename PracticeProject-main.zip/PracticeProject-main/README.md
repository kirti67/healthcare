# PracticeProject

git clone #https//
cd proectName
code .



server.js --> routes --> controllers --> middlewares 
.                                    --> model

